package stacs.arcade.backgammon;

public class IllegalMoveException extends Exception {

    public IllegalMoveException(String string) {
        super(string);
    }
}
